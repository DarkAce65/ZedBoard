#include <iostream>
#include "GPIO.h" 

int pulse(int theta) {
	return (int) (1500 + (theta - 90) * (6 + 2.0 / 3.0));
}

int main() 
{ 
	int servo;
	int theta;

	std::cout << "Enter a number between 1 and 5: \n1: base\n2: bicep\n3: elbow\n4: wrist\n5: gripper.";
	std::cin >> servo;

	std::cout << "Enter an angle between 20 and 160.";
	std::cin >> theta;

	if (servo < 1 || servo > 5 || theta < 20 || theta > 160) {
		std::cout << "Invalid parameters.";
	}
	
	int pin;
	switch(servo) {
		case 1:
			pin = 13;
			break;
		case 2:
			pin = 10;
			break;
		case 3:
			pin = 11;
			break;
		case 4:
			pin = 12;
			break;
		case 5:
			pin = 0;
			break;
		default:
			std::cout << "Invalid servo";
			break;

	}

	GPIO gpio(pin);
	// Generate PWM signal with 20ms period and 1.5ms on time. 
	// Generate 400 periods, this will take 20ms * 400 iterations = 8s 
	gpio.GeneratePWM(20000, pulse(theta), 400); 
	// Done 
	return 0; 
}
