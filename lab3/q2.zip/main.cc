#include "Wiimote.h"

int main() {
	Wiimote w;
	w.listen();

	return 0;
}
